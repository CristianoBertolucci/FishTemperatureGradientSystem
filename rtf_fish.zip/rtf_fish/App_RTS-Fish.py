# Recording Fish App. Ver.3 20Jan2023 by F. Conti, G. de Alba,
# J.F. L�pez-Olmeda, L. M. Vera, G. Lucon-Xiccato, E. Mainardi,
# C. Silvia, M. Bottarelli, C. Bertolucci, 
# F.J. S�nchez-V�zquez, E. Gatto.

# Title: Daily rhythms of thermal preference in zebrafish: an 
# automated solution to generate a horizontal thermal gradient 
# and long-period record fish behaviour.

# Github link dedicated to the project XX

# Application for recording long-term video based on picamera
# Recording app based on picamera (Jolles, 2021). 
# GUI built on tkinter

# @This research was funded by the European Union's Horizon 2020
#research and innovation programme under Marie Sk?odowska-Curie
#grant No 956129 "EasyTRAIN", and by research contract co
#financing by European Union�PON Ricerca e Innovazione 2014�2020
#ai sensi dell'art. 24, comma 3, lett. a, della Legge 30
#dicembre 2010, n. 240 e s.m.i. e del D.M. 10 agosto 2021 n.
#1062 to E.G. We are thankful to Andrea Margutti for building
#apparatuses and to Sara Romagnoli for help in testing the
#subjects.


#-------import library

from tkinter import *
import picamera
from datetime import datetime
from time import *
from PIL import Image, ImageTk
from os import *
from threading import Thread
import time


#---Create variables 
camera = picamera.PiCamera()

#holds the state of the camera
active = False
recording_label = None 


#-----------------set function    

# CameraON function record fish behaviour.
# The function recorded X videos of X hours specified by user.
# Because the first frame from the first recorded video are 
# blurred/lower-quality ,the function generate a short video
# called trash (15s lenght) in the same folder.
# This was necessary to the camera for loading the update 
# recorded parameters. Then, the 'trash' video can be delected. 
# The users defined the folder where the videos would be saved.
# The suggested parameters are optimized for recording condition
# in the Behaviorual Biology Lab, Department of Life Sciences 
# and Biotechnology, Faculty of Biology, University of Ferrara,
# 44121 Ferrara, Italy 
# Other users should be changes the parameters according to 
# room conditions (light/distance/sizes of the tank).

def CameraON():
    global active
    if not active:
        camera.resolution=(1920,1080)
        #camera.rotation=180 #verify campera position before rotating
        camera.framerate = int(fps_value.get())
        camera.sensor_mode=int(sm_value.get())
        camera.shutter_speed=int(ssp_value.get())
        #camera.brightness=int(bright_value.get())
        #camera.contrast=int(contr_value.get())
        
        recording_label.config(text = "RECORDING",)
        cap_thread = CaptureThread(60*60*int(hrec_value.get()),nrec_value.get())
        cap_thread.start()
        active = True
    

#turn off the recording
def CameraOFF():
    global active
    print("manuallt stopping recording")
    recording_label.config(text = "NOT RECORDING",)

    #camera.stop_recording()
    active = False

#start preview of recording
def PreviewON():
    camera.preview_fullscreen=False
    camera.preview_window=(620, 320, 340, 480)
    camera.rotation=180
    camera.start_preview()

def PreviewOFF():
    camera.stop_preview()
    
    
class CaptureThread(Thread):
    def __init__(self, backup_delta,backup_times):
        Thread.__init__(self)
        self.starting_time = 0
        self.backup_delta = backup_delta
        self.backup_times = backup_times
        
    def run(self):
        global active
        global path_text
        global camera

        
        path=path_text.get()
        
        print(path)
        camera.start_recording(f'{path}'+'trash.h264')
        camera.wait_recording(15)
        camera.stop_recording()
        remove(f'{path}'+'trash.h264')
        print("starting recording")
        i = 0
        print(active)
        while i <(1+int(self.backup_times)) and active:
            camera.start_recording(f'{path}'+str(i)+'Video.h264')               
        
            print(str(i)+ " i index")
            #START CAPTURE HERE
            delta = 0
            self.starting_time = time.time()
            while active == True and delta < self.backup_delta:
                delta = round(time.time() - self.starting_time)
                print(delta, " - " , self.backup_delta)              
                print("Frame acquired%d"%(delta))
                camera.wait_recording(1)
  
  
            camera.stop_recording()
            i = i + 1
            if active == False:
                print("stopped2")
        
        #reset the state
        active = False
            

            
#-------------------------------- ControlThread class------------------------------------------
class ControlThread(Thread):
    def run(self):
        global active
        #print(2)
        time.sleep(15)
        active = False

        #end capture
        #camera.stop_recording()
        #CAPTURE_THREAD.JOIN
    
#----------------create the GUI window
# The interface is based on tkinter. Briefly, each object is
# placed inside a window; thus the users need to declare the
# "mother"-windows where all smaller windows were been placed
# inside. The function pack() has been used.

root=Tk()
root.title('RTS-Fish')
root.geometry("590x580")


#create the first windows
title_frame = Frame(root,bg="blue",bd=0)
title_frame.pack(side='top',fill='both')

conf_frame = Frame(root,bg="lightgrey",bd=0)
conf_frame.pack(side='top',fill='both')
button_frame = Frame(root,bg="lightgrey",bd=0)
button_frame.pack(side='top',fill='both')
copyright_frame = Frame(root,bg="white",bd=0)
copyright_frame.pack(side='bottom',fill='both')
status_frame = Frame(root,bg="lightgrey",bd=0)
status_frame.pack(side='bottom',fill='both')

#----Title label + logo RTS-Fish
title_label=Label(title_frame,text="  Recording Temperature System - Fish (RTS-Fish)            ",
                  font=("Times",14),bg="blue",fg="white").pack(side="left",pady=10)

path_logo=f'{path.dirname(path.abspath(__file__))}'+'/resources_images/logo.png'
image1 = Image.open(path_logo).resize((80,80))
img1 = ImageTk.PhotoImage(image1)
logo_label=Label(title_frame,  image=img1).pack(side="right",padx=5,  pady=5)

#---- User-configuration Setting
#--- qui user può decidere come modificare diversi parametri.
#- Each set of (_value,_box, lalbel) define a specific parameters. List:
#-nrec numero di video
#-hrec ore di registrazion
#-fps frame per second
#-ssp shutter speed
#-sm sensor mode
#- brightness
# - contrast
# - effect (see list)
# -white balance (see list)

nrec_frame=Frame(conf_frame,bg="lightgrey")
nrec_frame.pack(side='top')
nrec_value=StringVar(value=1)
nrec_box=Spinbox(nrec_frame,from_=1, to=20000, textvariable=nrec_value,font=('Times',12),width=10,wrap=True).pack(side=RIGHT,padx=120)
nrec_label=Label(nrec_frame,text="Number of Video Recordings:",font=('Times',12),bg="lightgrey").pack(side=LEFT,padx=10,pady=5)

hrec_frame=Frame(conf_frame,bg="lightgrey")
hrec_frame.pack(side='top')
hrec_value=StringVar(value=1)
hrec_box=Spinbox(hrec_frame,from_=1, to=20000, textvariable=hrec_value,font=('Times',12),width=10,wrap=True).pack(side=RIGHT,padx=120)
hrec_label=Label(hrec_frame,text="Recordings hours per video: ",font=('Times',12),bg="lightgrey").pack(side=RIGHT,padx=15,pady=5)

fps_frame=Frame(conf_frame,bg="lightgrey")
fps_frame.pack(side='top')
fps_value=StringVar(value=1)
fps_box=Spinbox(fps_frame,from_=1, to=30, textvariable=fps_value,font=('Times',12),width=10,wrap=True).pack(side=RIGHT,padx=120)
fps_label=Label(fps_frame,text="FPS (1-30):",font=('Times',12),bg="lightgrey").pack(side=RIGHT,padx=70,pady=5)

ssp_frame=Frame(conf_frame,bg="lightgrey")
ssp_frame.pack(side='top')
ssp_value=StringVar(value=500000)
ssp_box=Spinbox(ssp_frame,from_=1,to=2000000,textvariable=ssp_value,font=('Times',12),width=10,wrap=True).pack(side=RIGHT,padx=120)
ssp_label=Label(ssp_frame,text="Shutter Speed:",font=('Times',12),bg="lightgrey").pack(side=RIGHT,padx=60,pady=5)

sm_frame=Frame(conf_frame,bg="lightgrey")
sm_frame.pack(side='top')
sm_value=StringVar(value=1)
sm_box=Spinbox(sm_frame,from_=1,to=3,textvariable=sm_value,font=('Times',12),width=10,wrap=True).pack(side=RIGHT,padx=120)
sm_label=Label(sm_frame,text="Sensor Mode (1/2/3):",font=('Times',12),bg="lightgrey").pack(side=RIGHT,padx=40,pady=5)

#contr_frame=Frame(conf_frame,bg="lightgrey")
#contr_frame.pack(side='top')
#contr_value=StringVar(value=50)
#contr_box=Spinbox(contr_frame,textvariable=contr_value,font=('Times',12),width=10,wrap=True).pack(side=RIGHT,padx=120)
#contr_label=Label(contr_frame, text="Contrast:",font=('Times',12),bg="lightgrey").pack(side=RIGHT,padx=79,pady=5)

#bright_frame=Frame(conf_frame,bg="lightgrey")
#bright_frame.pack(side='top')
#bright_value=StringVar(value=50)
#bright_box=Spinbox(bright_frame,textvariable=bright_value,font=('Times',12),width=10,wrap=True).pack(side=RIGHT,padx=120)
#bright_label=Label(bright_frame, text="Brightness:", font=('Times',12),bg="lightgrey").pack(side=RIGHT,padx=73,pady=5)

path_frame=Frame(conf_frame,bg="lightgrey")
path_frame.pack(side='top')
path_text=StringVar()
path_text.set('/home/pi/Desktop/Name_Folder/')
path_box=Entry(path_frame,textvariable=path_text,width=40,borderwidth=5).pack(side=RIGHT,padx=5)
path_label=Label(path_frame,text="Select save folder:",font=('Times',12),bg="lightgrey").pack(side=RIGHT,padx=50,pady=5)


#----button recording routing

prevbut_frame=Frame(button_frame,bg="lightgrey")
prevbut_frame.pack(side='left')

Button(prevbut_frame,text="Preview Camera",font=('Times',14),command=PreviewON,activebackground="green").pack(padx=5, pady=5)
Button(prevbut_frame,text="Preview OFF",font=('Times',14),command=PreviewOFF).pack(padx=5, pady=5)

cambut_frame=Frame(button_frame,bg="lightgrey")
cambut_frame.pack(side='right')
Button(cambut_frame,text="Start Recording",font=('Times',14),command=CameraON,activebackground="green").pack(padx=5, pady=5)
Button(cambut_frame,text="Stop Recording",font=('Times',14),command=CameraOFF,activebackground="red").pack(padx=5, pady=5)
recording_label = Label(button_frame, text = "NOT RECORDING", relief = RAISED)
recording_label.pack(padx = 5, pady=25)
#----------------
date = datetime.now()
time_string = strftime('%H:%M:%S %p')
statusDate_label=Label(status_frame,text="Starting recording date: "+f"{date:%A, %B %d, %Y}",font=('Times',12),bg="lightgrey").pack(side="top",anchor=W,padx=5, pady=5)
statusTime_label=Label(status_frame,text="Starting recording time: "+time_string,font=('Times',12),bg="lightgrey").pack(side="top",anchor=W,padx=5, pady=5)



#---copyright label
infoc_label=Label(copyright_frame,text="@The current project\n has been supported by:",font=("Times",8),bg="white",fg="black")
infoc_label.pack(side="left")


sponsor_easytrain=f'{path.dirname(path.abspath(__file__))}'+'/resources_images/easytrain.png'
image2 = Image.open(sponsor_easytrain).resize((480,65))
img2 = ImageTk.PhotoImage(image2)
sponsor1_label=Label(copyright_frame,  image=img2,bg="white")
sponsor1_label.pack(side="bottom",padx=5,  pady=5)

sponsor_pon=f'{path.dirname(path.abspath(__file__))}'+'/resources_images/pon.png'
image3 = Image.open(sponsor_pon).resize((480,50))
img3 = ImageTk.PhotoImage(image3)
sponsor2_label=Label(copyright_frame,  image=img3)
sponsor2_label.pack(side="bottom",padx=5,  pady=5)


#######################

#- Run the app

root.mainloop()
